#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

void syscall_init (void);
void close_all(void);

#endif /* userprog/syscall.h */
